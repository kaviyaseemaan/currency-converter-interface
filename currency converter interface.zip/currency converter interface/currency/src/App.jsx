import { useEffect, useRef, useState } from "react";
import "./App.css";

const currencies = [
  { code: "INR", name: "Indian Rupee", flag: "🇮🇳", symbol: "₹" },
  { code: "USD", name: "US Dollar", flag: "🇺🇸", symbol: "$" },
  { code: "EUR", name: "Euro", flag: "🇪🇺", symbol: "€" },
  { code: "GBP", name: "British Pound", flag: "🇬🇧", symbol: "£" },
  { code: "AED", name: "UAE Dirham", flag: "🇦🇪", symbol: "د.إ" },
  { code: "JPY", name: "Japanese Yen", flag: "🇯🇵", symbol: "¥" },
  { code: "CAD", name: "Canadian Dollar", flag: "🇨🇦", symbol: "$" },
  { code: "AUD", name: "Australian Dollar", flag: "🇦🇺", symbol: "$" },
];

const rates = {
  INR: { USD: 0.012, EUR: 0.011, GBP: 0.0094, AED: 0.044, JPY: 1.76, CAD: 0.016, AUD: 0.018 },
  USD: { INR: 83.5, EUR: 0.92, GBP: 0.79, AED: 3.67, JPY: 147, CAD: 1.36, AUD: 1.52 },
  EUR: { INR: 90.8, USD: 1.09, GBP: 0.86, AED: 4.0, JPY: 160, CAD: 1.48, AUD: 1.65 },
  GBP: { INR: 105.5, USD: 1.27, EUR: 1.16, AED: 4.66, JPY: 186, CAD: 1.72, AUD: 1.92 },
  AED: { INR: 22.75, USD: 0.272, EUR: 0.25, GBP: 0.215, JPY: 40.1, CAD: 0.371, AUD: 0.414 },
  JPY: { INR: 0.568, USD: 0.0068, EUR: 0.00625, GBP: 0.00538, AED: 0.0249, CAD: 0.00925, AUD: 0.0103 },
  CAD: { INR: 61.4, USD: 0.735, EUR: 0.676, GBP: 0.581, AED: 2.7, JPY: 108, AUD: 1.12 },
  AUD: { INR: 55.8, USD: 0.658, EUR: 0.606, GBP: 0.521, AED: 2.42, JPY: 96.5, CAD: 0.893 },
};

const spendingData = {
  USD: [
    { icon: "🍔", name: "Fast Food", price: 15 },
    { icon: "☕", name: "Coffee", price: 5 },
    { icon: "🎬", name: "Movie Ticket", price: 15 },
    { icon: "🍕", name: "Pizza", price: 20 },
  ],
  EUR: [
    { icon: "🍔", name: "Fast Food", price: 12 },
    { icon: "☕", name: "Coffee", price: 4 },
    { icon: "🎬", name: "Movie Ticket", price: 12 },
    { icon: "🍕", name: "Pizza", price: 15 },
  ],
  GBP: [
    { icon: "🍔", name: "Fast Food", price: 10 },
    { icon: "☕", name: "Coffee", price: 4 },
    { icon: "🎬", name: "Movie Ticket", price: 12 },
    { icon: "🍕", name: "Pizza", price: 14 },
  ],
  AED: [
    { icon: "🍔", name: "Fast Food", price: 30 },
    { icon: "☕", name: "Coffee", price: 18 },
    { icon: "🎬", name: "Movie Ticket", price: 40 },
    { icon: "🍕", name: "Pizza", price: 45 },
  ],
  JPY: [
    { icon: "🍔", name: "Fast Food", price: 900 },
    { icon: "☕", name: "Coffee", price: 500 },
    { icon: "🎬", name: "Movie Ticket", price: 2000 },
    { icon: "🍕", name: "Pizza", price: 1800 },
  ],
};

function getCurrency(code) {
  return currencies.find((currency) => currency.code === code);
}

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [amount, setAmount] = useState(10000);
  const [from, setFrom] = useState("INR");
  const [to, setTo] = useState("USD");
  const [history, setHistory] = useState([]);
  const [favorites, setFavorites] = useState(["USD", "EUR", "GBP"]);
  const firstConversion = useRef(true);

  const rate = from === to ? 1 : rates[from]?.[to] || 1;
  const convertedAmount = Number(amount || 0) * rate;

  useEffect(() => {
    const savedHistory = localStorage.getItem("currencyHistory");

    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (error) {
        console.error("Could not load history:", error);
      }
    }
  }, []);

  useEffect(() => {
    if (firstConversion.current) {
      firstConversion.current = false;
      return;
    }

    if (amount === "" || Number(amount) <= 0 || !from || !to) {
      return;
    }

    const timer = setTimeout(() => {
      const newConversion = {
        id: Date.now(),
        from,
        to,
        amount: Number(amount),
        result: convertedAmount,
        date: new Date().toLocaleString(),
      };

      setHistory((previousHistory) => {
        const latest = previousHistory[0];

        if (
          latest &&
          latest.from === from &&
          latest.to === to &&
          Number(latest.amount) === Number(amount)
        ) {
          return previousHistory;
        }

        const updatedHistory = [newConversion, ...previousHistory].slice(0, 6);

        localStorage.setItem("currencyHistory", JSON.stringify(updatedHistory));
        return updatedHistory;
      });
    }, 800);

    return () => clearTimeout(timer);
  }, [amount, from, to, convertedAmount]);

  function handleSwap() {
    setFrom(to);
    setTo(from);
  }

  function clearHistory() {
    setHistory([]);
    localStorage.removeItem("currencyHistory");
  }

  function toggleFavorite(code) {
    if (favorites.includes(code)) {
      setFavorites(favorites.filter((item) => item !== code));
    } else {
      setFavorites([...favorites, code]);
    }
  }

  const targetCurrency = getCurrency(to);

  const spendingItems = spendingData[to] || [
    { icon: "🍔", name: "Meal", price: 10 },
    { icon: "☕", name: "Coffee", price: 5 },
    { icon: "🎬", name: "Movie", price: 15 },
    { icon: "🛍️", name: "Shopping", price: 25 },
  ];

  return (
    <div className={darkMode ? "app dark" : "app"}>
      <nav className="navbar">
        <div className="brand">
          <div className="brand-icon">↗</div>
          <div>
            <h2>Convertly</h2>
            <span>Smart Currency</span>
          </div>
        </div>

        <div className="nav-right">
          <div className="live-status">
            <span></span>
            Sample Rates
          </div>

          <button
            className="theme-button"
            onClick={() => setDarkMode(!darkMode)}
          >
            {darkMode ? "☀️" : "🌙"}
          </button>
        </div>
      </nav>

      <header className="hero">
        <div className="hero-text">
          <span className="badge">✨ SMART CURRENCY EXPERIENCE</span>

          <h1>
            Money without <span>borders.</span>
          </h1>

          <p>
            Convert currencies, compare global values and discover what your
            money can buy around the world.
          </p>
        </div>
      </header>

      <main className="container">
        <section className="converter-card">
          <div className="section-heading">
            <div>
              <span className="small-label">CONVERTER</span>
              <h2>Convert your money</h2>
            </div>

            <div className="updated">● Automatic conversion</div>
          </div>

          <div className="converter-grid">
            <div className="currency-box">
              <label>From</label>

              <div className="currency-select">
                <select value={from} onChange={(e) => setFrom(e.target.value)}>
                  {currencies.map((currency) => (
                    <option key={currency.code} value={currency.code}>
                      {currency.flag} {currency.code}
                    </option>
                  ))}
                </select>
              </div>

              <div className="amount-input">
                <span>{getCurrency(from).symbol}</span>

                <input
                  type="number"
                  min="0"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter amount"
                />
              </div>
            </div>

            <button
              className="swap-button"
              onClick={handleSwap}
              aria-label="Swap currencies"
            >
              ⇄
            </button>

            <div className="currency-box">
              <label>To</label>

              <div className="currency-select">
                <select value={to} onChange={(e) => setTo(e.target.value)}>
                  {currencies.map((currency) => (
                    <option key={currency.code} value={currency.code}>
                      {currency.flag} {currency.code}
                    </option>
                  ))}
                </select>
              </div>

              <div className="result">
                <span>{targetCurrency.symbol}</span>

                <strong>
                  {convertedAmount.toLocaleString(undefined, {
                    maximumFractionDigits: 2,
                  })}
                </strong>
              </div>
            </div>
          </div>

          <div className="rate-info">
            <span>
              1 {from} = {rate.toFixed(4)} {to}
            </span>

            <span className="live-rate">● Automatic conversion</span>
          </div>
        </section>

        <section className="favorites-section">
          <div className="section-title">
            <span className="small-label">QUICK ACCESS</span>
            <h2>Favorite currencies</h2>
          </div>

          <div className="favorite-list">
            {favorites.map((code) => {
              const currency = getCurrency(code);

              return (
                <button
                  className="favorite-card"
                  key={code}
                  onClick={() => setTo(code)}
                >
                  <span className="flag">{currency.flag}</span>

                  <div>
                    <strong>{currency.code}</strong>
                    <small>{currency.name}</small>
                  </div>

                  <span className="arrow">→</span>
                </button>
              );
            })}
          </div>
        </section>

        <section className="multi-section">
          <div className="section-title">
            <div>
              <span className="small-label">GLOBAL VIEW</span>
              <h2>Compare your money</h2>
            </div>

            <p>
              {getCurrency(from).symbol}
              {Number(amount).toLocaleString()} across popular currencies
            </p>
          </div>

          <div className="comparison-grid">
            {currencies
              .filter((currency) => currency.code !== from)
              .slice(0, 6)
              .map((currency) => {
                const conversion =
                  from === currency.code
                    ? Number(amount)
                    : Number(amount) * (rates[from]?.[currency.code] || 1);

                return (
                  <div className="comparison-card" key={currency.code}>
                    <div className="comparison-top">
                      <span>{currency.flag}</span>
                      <strong>{currency.code}</strong>
                    </div>

                    <h3>
                      {currency.symbol}
                      {conversion.toLocaleString(undefined, {
                        maximumFractionDigits: 2,
                      })}
                    </h3>

                    <small>{currency.name}</small>
                  </div>
                );
              })}
          </div>
        </section>

        <div className="two-column">
          <section className="panel">
            <div className="panel-header">
              <div>
                <span className="small-label">MARKET INSIGHT</span>
                <h2>Exchange rate trend</h2>
              </div>

              <span className="trend-up">+2.4%</span>
            </div>

            <div className="chart">
              <div className="chart-line line1"></div>
              <div className="chart-line line2"></div>
              <div className="chart-line line3"></div>

              <svg
                viewBox="0 0 500 180"
                role="img"
                aria-label="Illustrative exchange rate trend"
              >
                <polyline
                  points="
                    0,145
                    70,125
                    120,140
                    175,95
                    230,110
                    280,75
                    335,88
                    390,48
                    450,65
                    500,35
                  "
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="4"
                />
              </svg>
            </div>

            <div className="chart-footer">
              <span>7 days ago</span>
              <span>Today</span>
            </div>
          </section>

          <section className="panel">
            <div className="panel-header">
              <div>
                <span className="small-label">SMART INSIGHT</span>
                <h2>What can you buy?</h2>
              </div>

              <span className="lightbulb">💡</span>
            </div>

            <p className="spending-intro">
              Your{" "}
              <strong>
                {targetCurrency.symbol}
                {convertedAmount.toLocaleString(undefined, {
                  maximumFractionDigits: 0,
                })}
              </strong>{" "}
              could roughly cover:
            </p>

            <div className="spending-list">
              {spendingItems.map((item) => {
                const quantity = Math.floor(convertedAmount / item.price);

                return (
                  <div className="spending-item" key={item.name}>
                    <span className="spending-icon">{item.icon}</span>

                    <div>
                      <strong>{item.name}</strong>
                      <small>
                        ~{item.price} {to}
                      </small>
                    </div>

                    <b>×{quantity}</b>
                  </div>
                );
              })}
            </div>

            <p className="disclaimer">
              *Prices are illustrative estimates and may vary by location and
              provider.
            </p>
          </section>
        </div>

        <section className="history-section">
          <div className="section-title">
            <div>
              <span className="small-label">YOUR ACTIVITY</span>
              <h2>Recent conversions</h2>
            </div>

            {history.length > 0 && (
              <button className="clear-button" onClick={clearHistory}>
                Clear history
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <div className="empty-history">
              <div>🕘</div>
              <h3>No conversions yet</h3>
              <p>Your recent conversions will appear here.</p>
            </div>
          ) : (
            <div className="history-list">
              {history.map((item) => {
                const fromCurrency = getCurrency(item.from);
                const toCurrency = getCurrency(item.to);

                return (
                  <div className="history-item" key={item.id}>
                    <div className="history-currencies">
                      <span>{fromCurrency.flag}</span>
                      <strong>{item.from}</strong>
                      <span>→</span>
                      <span>{toCurrency.flag}</span>
                      <strong>{item.to}</strong>
                    </div>

                    <div className="history-value">
                      <strong>
                        {fromCurrency.symbol}
                        {Number(item.amount).toLocaleString()}
                      </strong>

                      <span>→</span>

                      <strong>
                        {toCurrency.symbol}
                        {Number(item.result).toLocaleString(undefined, {
                          maximumFractionDigits: 2,
                        })}
                      </strong>
                    </div>

                    <small>{item.date}</small>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </main>

      <footer>
        <div className="footer-brand">↗ Convertly</div>

        <p>Smart currency conversion for a connected world.</p>

        <span>Built with React • JSX • CSS</span>
      </footer>
    </div>
  );
}

export default App;