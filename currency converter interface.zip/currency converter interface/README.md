# Simple React JS Practice

This project contains simple examples of:

1. useState
2. onClick
3. onChange
4. Form handling
5. Form validation
6. Simple page switching
7. API fetching with fetch()
8. useEffect
9. Array map()

## Run

```bash
npm install
npm run dev
```

Open the local URL shown by Vite.
